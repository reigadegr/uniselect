package com.xxx.misc.test

data class Test(
    val id: Int? = null,
    val name: String? = null
)
