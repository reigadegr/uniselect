package com.xxx.misc.test

interface testService {
    fun fid(id: Int): Test?
}
