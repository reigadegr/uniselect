package com.xxx.pojo


data class Course_selection(
    val id: Int? = null,
    val student_id: String? = null,
    val course_id: Int? = null,
    val course_name: String? = null
)
