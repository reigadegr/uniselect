package com.xxx.pojo


data class Teacher(
    val id: Int? = null,
    val teacher_id: String? = null,
    val name: String? = null,
    val password: String? = null,
    val description: String? = null
)

