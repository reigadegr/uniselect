package com.xxx.pojo

data class User(
    var id: Int? = null,
    var student_id: String? = null,
    var name: String? = null,
    var password: String? = null,
    var major: String? = null,
    var ban: String? = null,
    var type: String? = null
)
